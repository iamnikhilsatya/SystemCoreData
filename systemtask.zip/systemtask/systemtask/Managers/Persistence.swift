//
//  Persistence.swift
//  systemtask
//
//  Created by SMART TECHIES on 22/08/24.
//

import CoreData

struct PersistenceController {
    static let shared = PersistenceController()
    let container: NSPersistentContainer
    
    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "systemtask")
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        container.viewContext.automaticallyMergesChangesFromParent = true
        addMockData(to: container.viewContext)
    }
    
    func addMockData(to viewContext: NSManagedObjectContext) {
        
        do {
            let videos = try JSONDecoder().decode([Video].self, from: jsonData)
            
            for video in videos {
                let fetchRequest: NSFetchRequest<Item> = Item.fetchRequest()
                fetchRequest.predicate = NSPredicate(format: "video_id == %@", video.video_id)
                
                let existingItems = try viewContext.fetch(fetchRequest)
                if existingItems.isEmpty {
                    // If the video doesn't exist, add it
                    let newItem = Item(context: viewContext)
                    newItem.video_id = video.video_id
                    newItem.video_fk = video.video_fk
                    newItem.videourl = video.videourl
                    newItem.thumbnail = video.thumbnail
                    newItem.video_local_title = video.video_local_title
                    newItem.video_title = video.video_title
                } else {
                    print("Item with video_id \(video.video_id)")
                }
            }
            
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}
