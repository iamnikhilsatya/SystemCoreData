//
//  ContentView.swift
//  systemtask
//
//  Created by SMART TECHIES on 22/08/24.
//

import SwiftUI
import CoreData

struct VideoListView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Item.video_id, ascending: false)],
        animation: .default)
    private var items: FetchedResults<Item>
    @State private var downloadProgress: [String: Double] = [:]
    @StateObject private var viewModel = VideoDownloadViewModel()
    
    
    var body: some View {
        NavigationView {
            List {
                ForEach(items) { item in
                    NavigationLink() {
                        VideoDetailView(item: item)
                    } label: {
                        HStack {
                            if let thumbnailURL = item.thumbnail, let url = URL(string: thumbnailURL) {
                                AsyncImage(url: url) { image in
                                    image.resizable()
                                        .scaledToFit()
                                        .frame(width: 50, height: 50)
                                        .cornerRadius(16)
                                } placeholder: {
                                    ProgressView()
                                }
                                .frame(width: 50, height: 50)
                            } else {
                                Rectangle()
                                    .fill(Color.gray)
                                    .frame(width: 50, height: 50)
                            }
                            VStack(alignment: .leading) {
                                Text(item.video_title ?? "Unknown Title")
                                    .font(.headline)
                                Text(item.video_local_title ?? "Unknown Local Title")
                                    .font(.subheadline)
                                if item.downloadStatus == "Completed" {
                                    Text("Download Completed")
                                        .font(.caption)
                                        .foregroundColor(.green)
                                } else {
                                    if let progress = viewModel.downloadProgress[item.video_id ?? ""] {
                                        ProgressView(value: progress, total: 1.0)
                                            .frame(width: 150, height: 5)
                                    }
                                    Text("Download Item")
                                        .foregroundColor(.white)
                                        .padding(20)
                                        .background(Color.blue)
                                        .cornerRadius(16)
                                        .onTapGesture {
                                            print("Tapped")
                                            viewModel.downloadVideo(item: item, context: viewContext)                                            }
                                }
                            }
                        }
                        
                    }
                }
            }
        }
    }
}
