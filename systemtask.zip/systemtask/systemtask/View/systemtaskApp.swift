//
//  systemtaskApp.swift
//  systemtask
//
//  Created by SMART TECHIES on 22/08/24.
//

import SwiftUI

@main
struct systemtaskApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            VideoListView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
