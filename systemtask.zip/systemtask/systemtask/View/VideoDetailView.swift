import SwiftUI
import AVKit

struct VideoDetailView: View {
    @Environment(\.managedObjectContext) private var viewContext
    var item: Item?
    
    @State private var player: AVPlayer?
    @State private var isPlaying: Bool = false
    
    var body: some View {
        VStack {
            if let thumbnailURL = item?.thumbnail, let url = URL(string: thumbnailURL) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .success(let image):
                        image.resizable()
                            .scaledToFit()
                    case .failure:
                        Image(systemName: "exclamationmark.triangle")
                    @unknown default:
                        EmptyView()
                    }
                }
                .frame(height: 200)
                .cornerRadius(16)
            }
            
            Text(item?.video_title ?? "Unknown Title")
                .font(.headline)
                .padding(.bottom)
            Text(item?.video_local_title ?? "Unknown Local Title")
                .font(.subheadline)
                .padding(.bottom)
            
            if item?.downloadStatus == "Completed" {
                Button(action: {
                    togglePlayPause()
                }) {
                    Text(isPlaying ? "Pause Video" : "Play Video")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                
                VideoPlayer(player: player)
                    .frame(height: 300)
                    .onAppear {
                        guard let videoUrlString = item?.videourl,
                              let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
                            return
                        }
                        
                        let videoURL = documentsDirectory.appendingPathComponent(URL(string: videoUrlString)?.lastPathComponent ?? "")
                        player = AVPlayer(url: videoURL)
                    }
            } else {
                Text("Video not downloaded")
                    .foregroundColor(.red)
            }
            
            Spacer()
        }
        .navigationTitle("Video Details")
        .padding()
    }
    
    private func togglePlayPause() {
        if isPlaying {
            player?.pause()
        } else {
            player?.play()
        }
        isPlaying.toggle()
    }
}
