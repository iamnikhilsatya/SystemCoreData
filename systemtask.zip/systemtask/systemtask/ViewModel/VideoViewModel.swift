import SwiftUI
import Combine
import CoreData

class VideoDownloadViewModel: ObservableObject {
    @Published var downloadProgress: [String: Double] = [:]
    
    func downloadVideo(item: Item, context: NSManagedObjectContext) {
        guard let urlString = item.videourl, let url = URL(string: urlString) else { return }
        print("Download Started")
        
        let downloadTask = URLSession.shared.downloadTask(with: url) { localURL, response, error in
            guard let localURL = localURL, error == nil else { return }
            print("Download Started  went here")
            
            // Move downloaded file to documents directory
            let fileManager = FileManager.default
            do {
                print("Into Download Started")
                let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
                print("Download documentsDirectory")
                let destinationURL = documentsDirectory.appendingPathComponent(url.lastPathComponent)
                print("Download destinationURL")
                try fileManager.moveItem(at: localURL, to: destinationURL)
                print("Download fileManager")
                
                // Update Core Data
                DispatchQueue.main.async {
                    item.downloadStatus = "Completed"
                    print("Download completed")
                    try? context.save()
                }
            } catch {
                print("Error saving file: \(error)")
            }
        }
        
        downloadTask.resume()
    }
}
