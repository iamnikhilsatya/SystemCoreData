import SwiftUI
import Combine
import CoreData

class VideoDownloadViewModel: ObservableObject {
    @Published var downloadProgress: [String: Double] = [:]
    private var cancellables = Set<AnyCancellable>()
    
    func downloadVideo(item: Item, context: NSManagedObjectContext) {
        guard let videoURLString = item.videourl, let url = URL(string: videoURLString) else { return }
        
        let downloadTask = URLSession.shared.downloadTask(with: url) { [weak self] localURL, response, error in
            guard let self = self, let localURL = localURL else { return }
            
            do {
                let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                let destinationURL = documentsDirectory.appendingPathComponent(url.lastPathComponent)
                try FileManager.default.moveItem(at: localURL, to: destinationURL)
                
                // Update download status in Core Data
                item.downloadStatus = "Completed"
                try context.save()
                
                // Remove progress from the dictionary after completion
                DispatchQueue.main.async {
                    self.downloadProgress[item.video_id ?? ""] = nil
                }
            } catch {
                print("Failed to move downloaded file: \(error)")
            }
        }
        
        // Observe download progress
        downloadTask.progress.publisher(for: \.fractionCompleted)
            .sink { [weak self] progress in
                DispatchQueue.main.async {
                    self?.downloadProgress[item.video_id ?? ""] = progress
                }
            }
            .store(in: &cancellables)
        
        downloadTask.resume()
    }
}
